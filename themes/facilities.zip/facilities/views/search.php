<div id="middle" class="scroll">
    <div id="search-results">
        <h1><?php echo Kohana::lang('ui_main.search'); ?></h1>
        <?php echo $search_info; ?>
        <?php echo $search_results; ?>
    </div>
</div>