Theme Name: Facilities
Description: Theme for mapping the location of facilities
Version: 1.0
Author: Whitespace (http://whitespace.io) + BongoHive (http://bongohive.com)
Author Email: us@whitespace.io